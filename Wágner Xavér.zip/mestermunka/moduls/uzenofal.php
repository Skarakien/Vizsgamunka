<h1>Jelenleg nem szerfelett eszes eme rettenetes egylet ehhez. 😔 Megkegyelmezel? 🙏</h1>
<a href="index.php">Vissza a főoldalra</a>