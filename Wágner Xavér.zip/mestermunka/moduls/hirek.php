<?php /*
require_once 'SQL/connection.php'; */
?>
<div class="hirek_box">
    <div class="frisshir">
        <h6>Friss hírek</h6>
            <?php
            $sql = "SELECT * FROM hirek ORDER BY hir_ID DESC LIMIT 1";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='hirbox'>{$row['hircim']}: {$row['hirido']}</p>";
                    echo "<img src='{$row['hirkep']}' alt='Hír kép'>";
                    echo "<p>{$row['hirszoveg']}</p></div>";
                }
            } else {
                echo "<p>Semmi nem történt errefelé...</p><br><p>Úgy látszik, kicsi a város.</p>";
            }
            ?>
    </div>
    <div class="regihir">
        <?php
        $sql = "SELECT * FROM hirek ORDER BY hir_ID DESC LIMIT 4 OFFSET 1";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='hirbox'>{$row['hircim']}: {$row['hirido']}</p>";
                echo "<img src='{$row['hirkep']}' alt='Hír kép'>";
                echo "<p>{$row['hirszoveg']}</p></div>";
            }
        }
        ?>
    </div>
</div>
