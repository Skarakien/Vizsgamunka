<?php
/*session_start();
require_once 'SQL/connection.php';
if (!isset($_SESSION['loggedin']) || $_SESSION['rank'] > 1) {
    die("Ejnyebejnye, rosszgyerek!");
}*/
?>
<div class="konténer" style="display: grid; grid-auto-flow: row; grid-gap: 10px; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));">
    <div class="hirkezelo" style="border: 3px solid black; padding: 20px; margin: 20px;">
        <h2>Hírek kezelése</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <label for="hircim">Hír címe:</label><br>
            <input type="text" id="hircim" name="hircim" required><br>
            <label for="hirszoveg">Hír szövege:</label><br>
            <textarea id="hirszoveg" name="hirszoveg" rows="4" cols="50" style="max-width: 95%;" required></textarea><br>
            <label for="hirkep">Hír kép linkje:</label><br>
            <input type="text" id="hirkep" name="hirkep"><br>
            <input type="submit" value="Hozzáadás">
        </form>
    </div>
    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $hircim = $_POST['hircim'];
        $hirszoveg = $_POST['hirszoveg'];
        $hirkep = $_POST['hirkep'];
        $hirido = $_POST[date('Y-m-d H:i:s')];
        $sql = "INSERT INTO hir (cim, szoveg, kep, ido) VALUES ('$hircim', '$hirszoveg', '$hirkep', '$hirido')";
    }
    ?>
    <div class="felhasznalokezelo" style="border: 3px solid black; padding: 20px; margin: 20px;">
        <h2>Felhasználók kezelése</h2>
        <form action="" method="post">
            <label for="felhasznalonev">Felhasználónév:</label><br>
            <input type="text" id="felhasznalonev" name="felhasznalonev"><br>
            <input type="submit" name="search_user" value="Keresés">
        </form><br><br>
        <?php
        if (isset($_POST['search_user'])) {
            $user = $_POST['felhasznalonev'];
            $sql = "SELECT * FROM regisztralt WHERE felhasznalonev = '$user'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<p>{$row['felhasznalonev']}: {$row['email']}</p>";
                }
            } else {
                echo "<p>Nincs ilyen felhasználó.</p>";
            }
        }
        ?>
        <form action="$_POST" method="post">
            <label for="felhasznalonev">Felhasználónév:</label><br>
            <input type="text" id="felhasznalonev" name="felhasznalonev" required><br>
            <label for="jelszo">Jelszó:</label><br>
            <input type="text" id="jelszo" name="jelszo" required><br>
            <label for="felhasz_osztaly">Jogosultság:</label><br>
            <select id="felhasz_osztaly" name="felhasz_osztaly" required>
                <option value="1">Admin</option>
                <option value="2">Sofőr</option>
                <option value="3">Szerelő</option>
                <option value="4">Utas</option>
            </select><br>
            <label for="email">Email:</label><br>
            <input type="text" id="email" name="email" required><br>
            <input type="submit" name="letrehoz" value="Felhasználó létrehozása"><br>
            <input type="submit" name="torol" value="Felhasználó törlése"><br>
            <input type="submit" name="frissit" value="Felhasználó frissítése"><br>
        </form>
    </div>
    <?php
    if (isset($_POST['torol'])) {
        $user_id = $_POST['felhasznalonev'];
        $sql = "SELECT * FROM regisztralt WHERE felhasznalonev = '$user_id'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $user_id = $row['id'];
            }
        } else {
            echo "<script>alert('Ne legyél részeg, nincs ilyen.');</script>";
        }
        $sql = "SELECT * FROM regisztralt WHERE id = '$user_id'";
        $user_id = $_GET['id'];
        $sql = "DELETE FROM regisztralt WHERE id = '$user_id'";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Felhasználó törölve.');</script>";
        } else {
            echo "<script>alert('Ez most nem jött össze.');</script>" . $conn->error;
        }
    }
    if (isset($_POST['letrehoz'])) {
        $username = $_POST['felhasznalonev'];
        $password = $_POST['jelszo'];
        $rank = $_POST['felhasz_osztaly'];
        $sql = "INSERT INTO regisztralt (felhasznalonev, jelszo, felhasz_osztaly) VALUES ('$username', '$password', '$rank')";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Felhasználó létrehozva.');</script>";
        } else {
            echo "<script>alert('Hoppá!');</script>" . $conn->error;
        }
    }
    if (isset($_POST['frissit'])) {
        $user_id = $_POST['id'];
        $username = $_POST['felhasznalonev'];
        $password = $_POST['jelszo'];
        $rank = $_POST['felhasz_osztaly'];
        $sql = "UPDATE users SET felhasznalonev='$username', jelszo='$password', felhasz_osztaly='$rank' WHERE id='$user_id'";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Felhasználó frissítve.');</script>";
        } else {
            echo "<script>alert('Valami félresiklott...');</script>" . $conn->error;
        }
    }
    ?>
    <div class="reklamkezelo" style="border: 3px solid black; padding: 20px; margin: 20px;">
        <h2>Reklámok kezelése</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <label for="reklamnev">Reklám neve:</label><br>
            <input type="text" id="reklam" name="reklam" required><br>
            <label for="reklamkep">Reklámkép linkje:</label><br>
            <input type="text" id="reklamkep" name="reklam" required><br>
            <label for="reklamlink">Reklám redirect-je:</label><br>
            <input type="text" id="reklamlink" name="reklamlink" required><br>
            <input type="submit" value="Hozzáadás"><br><br>
            <label for="reklam_id">Reklám ID:</label><br>
            <input type="text" id="reklam_id" name="reklam_id" required><br>
            <input type="submit" name="delete_reklam" value="Törlés"><br>
            <input type="submit" name="search_reklam" value="Keresés"><br>
        </form>
    </div>
    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $reklamnev = $_POST['reklamnev'];
        $reklamkep = $_POST['reklamkep'];
        $reklamlink = $_POST['reklamlink'];
        $sql = "INSERT INTO reklamok (reklamnev , ) VALUES ('$reklamnev')";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Reklám hozzáadva.');</script>";
        } else {
            echo "<script>alert('Hálisten nem jó!');</script>" . $conn->error;
        }
    }
    if (isset($_POST['delete_reklam'])) {
        $reklam_id = serialize($_POST['reklam_id']['reklamnev']['reklamkep']['reklamlink']);
        $sql = "DELETE FROM reklamok (reklam_id, reklamnev, reklamkep, reklamlink) WHERE reklam_id = '$reklam_id'";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Reklám törölve.');</script>";
        } else {
            echo "<script>alert('Marad a reklámszünet.');</script>" . $conn->error;
        }
    }
    if (isset($_POST['search_reklam'])) {
        $reklamlink = $_POST['reklamlink'];
        $sql = "SELECT * FROM reklamok WHERE reklamlink = '$reklamlink'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<p>{$row['reklamnev']}: {$row['reklamlink']}</p>";
            }
        } else {
            echo "<script>alert('Nincs ilyen reklám. Folytatódhat a műsor.');</script>";
        }
    }
    ?>
    <div class="megallokezelo" style="border: 3px solid black; padding: 20px; margin: 20px;">
        <h2>Megállók kezelése</h2>
        <form action="" method="post">
            <label for="megallo_nev">Megálló neve:</label><br>
            <input type="text" id="megallo_nev" name="megallo_nev" required><br>
            <label for="koordinata">Megálló koordinátái:</label><br>
            <input type="number" id="koordinata" name="koordinata" required><br>
            <input type="submit" name="add_megallo" value="Hozzáadás"><br><br>
            <label for="megallo_id">Megálló ID:</label><br>
            <input type="text" id="megallo_id" name="megallo_id" required><br>
            <input type="submit" name="delete_megallo" value="Törlés">
        </form>
    </div>
    <?php
    if (isset($_POST['add_megallo'])) {
        $megallo_nev = $_POST['megallo_nev'];
        $megallo_koordinatak = $_POST['megallo_koordinatak'];
        $sql = "INSERT INTO megallok (megallo_nev, megallo_koordinatak) VALUES ('$megallo_nev', '$megallo_koordinatak')";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Megálló hozzáadva.');</script>";
        } else {
            echo "<script>alert('Kaki van a pallerben.');</script>" . $conn->error;
        }
    }
    if (isset($_POST['delete_megallo'])) {
        $megallo_id = $_POST['megallo_id'];
        $sql = "DELETE FROM megallok WHERE id = '$megallo_id'";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Megálló törölve.');</script>";
        } else {
            echo "<script>alert('A FEKETE TŰZ NEM SEGÍT NEKED! ITT ÚGYSE JÖSSZ ÁT!');</script>" . $conn->error;
        }
    }
    ?>
    <div class="jegykezelo" style="border: 3px solid black; padding: 20px; margin: 20px;">
        <h2>Jegyárak kezelése</h2>
        <form action="" method="post">
            <label for="jegy_index">Jegytípus index:</label><br>
            <input type="number" id="jegy_index" name="jegy_index" required><br>
            <label for="jegytipus">Jegy fajta:</label><br>
            <input type="text" id="jegytipus" name="jegytipus" required><br>
            <label for="jegyar">Jegy ára:</label><br>
            <input type="number" id="jegyar" name="jegyar" required><br>
            <input type="submit" name="add_jegytipus" value="Hozzáadás"><br>
            <input type="submit" name="delete_jegytipus" value="Törlés"><br>
            <input type="submit" name="update_jegytipus" value="Frissítés">
        </form>
        <?php
        if (isset($_POST['add_jegytipus'])) {
            $jegy_index = $_POST['jegy_index'];
            $jegytipus = $_POST['jegytipus'];
            $jegyar = $_POST['jegyar'];
            $sql = "INSERT INTO jegyek (jegy_index, jegytipus, jegyar) VALUES ('$jegy_index', '$jegytipus', '$jegyar')";
            if ($conn->query($sql) === TRUE) {
                echo "<script>alert('Jegytípus hozzáadva.');</script>";
            } else {
                echo "<script>alert('Ingyen utazunk?');</script>" . $conn->error;
            }
        }
        if (isset($_POST['delete_jegytipus'])) {
            $jegy_index = $_POST['jegy_index'];
            $sql = "DELETE FROM jegyek WHERE jegy_index = '$jegy_index'";
            if ($conn->query($sql) === TRUE) {
                echo "<script>alert('Jegytípus törölve.');</script>";
            } else {
                echo "<script>alert('Te ügyifogyi kaller!');</script>" . $conn->error;
            }
        }
        if (isset($_POST['update_jegytipus'])) {
            $jegy_index = $_POST['jegy_index'];
            $jegytipus = $_POST['jegytipus'];
            $jegyar = $_POST['jegyar'];
            $sql = "UPDATE jegyarak SET jegytipus='$jegytipus', jegyar='$jegyar' WHERE jegy_index='$jegy_index'";
            if ($conn->query($sql) === TRUE) {
                echo "<script>alert('Jegytípus frissítve.');</script>";
            } else {
                echo "<script>alert('Vagy inkább bérletet programozó tanfolyamra?');</script>" . $conn->error;
            }
        }
        ?>
    </div>
/* Hiányzik:
- sofőrök listázása
sofőrök NAPI menetlevelének létrehozása és lekérdezése
sofőrök menetlevelének lekérdezése tetszöleges idöponttól tetszöleges idöpontig
 - szerelők listázása
szerelőkhöz busz küldése
szerelők javítási jelentésének lekérdezése
 - buszok helyzetének lekérdezése (garázs/szervíz/úton)
 - kredit osztás (készpénz/bankkártya/utalás felvétele és jegyekre váltható token kiállítása)
felhasználó kredit egyenlegének lekérdezése
 - járat vonalának létrehozása, törlése; menetrendjének létrehozása; megálló beillesztése
menetidők változtatása */