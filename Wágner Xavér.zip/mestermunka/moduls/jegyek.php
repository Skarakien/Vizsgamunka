<?php // BE KÉNE FEJEZNI
/* session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['rank'] >= 4) {
    die("Nincs jogosultságod az oldal megtekintéséhez.");
} */
?>
<h1>Jegyeket tessék!</h1>
<form method="POST" action="moduls/jegyek.php">
    <label for="jegytipus">Jegy típusa:</label>
    <table>
    <!--- Típusok listázása, dinamikusan változó táblában (oszlopnevek: jegytipus, jegyar) -->
    </table>
    <input type="select" name="jegytipus" id="jegytipus" required>
    <input type="submit" value="Kijelöl" required>
    <label for="darab">Darab:</label>
    <input type="number" name="darab" id="darab" required>
    <!--- javascriptben kiszámolni a végösszeget --><br><br>
    <input type="submit" value="Hozzáadás">
    <!--- php kód, ami a kiválasztott jegy típusát és darabszámát hozzáadja a kosárhoz -->
    <input type="submit" value="Fizetés">
</form>