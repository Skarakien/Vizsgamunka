/* többi szerelő nevének listázása
alkatrészek igénylése (másik programba API küldés)
buszok fogadása
benn lévő buszok listázása
benn lévő buszok problémáinak megjelenítése
benn lévő buszok következő problémás elemének megnevezése
buszok küldése */