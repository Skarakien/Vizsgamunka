/* jegy vásárlása UTASNAK (CSAK vonaljegy vásárlás + kreditfeltöltés)
megálló menetrendjének listázása
vonal megállólistájának listázása
úthiba bejelentése: belső üzenőfal VAGY út tábla létrehozása SQLben
menetlevél lekérése (sofőr hozzárendelése a buszokhoz ÉS a vonalakhoz ÉS a menetrendekhez)
busz hibájának bejelentése
garázsban lévő buszok lekérdezése
elérhető sofőrök lekérdezése */