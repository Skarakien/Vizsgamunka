/* Üdvözöljük újra Mecsekhunyadi Volán társaság oldalán, kedves (insert [felhasznalonev])!<br>
Kérjük, válassza ki a kívánt menüpontot a bal oldali menüből.<br> 
Kérjük, vegye figyelembe, hogy a weboldalunkon csak tájékoztató jellegű és maximum szórakozásra alkalmas.<br>
A Mecsekhunyadi Volán társaság fenntartja a jogot az információk módosítására és frissítésére. BÁRMIKOR!<br>
A weboldalunk használata során gyűjtött adatokat bizalmasan kezeljük. Vagy legalábbis megpróbáljuk.<br> 
Az Üzenőfalon olvasottakért a felhasználók felelnek, és a moderátorok harapósak!
*/