<div><img src="images/construction.png" alt="Dolgozunk rajta"><br>
<h1>Sajnos még nincs kész, de gyere vissza később, hátha már működik!<br></h1>
<a href="index.php">Vissza a főoldalra</a>
</div>