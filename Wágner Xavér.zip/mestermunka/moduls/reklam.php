<?php
    require_once 'SQL/connection.php';
    $sql = "SELECT reklamkep, reklamlink FROM reklamok";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $ads = [];
        while ($row = $result->fetch_assoc()) {
            $ads[] = $row;
        }
        shuffle($ads);
        for ($i = 0; $i < 3; $i++) {
            echo "<div class='reklam' style='background-color: #ce9090; max-height: 200px; max-width: 150px;'>";
            echo "<img src='{$ads[$i]['reklamkep']}' alt='Reklám' style='max-width: 150px; max-height: 150px; object-fit: contain;'>";
            echo "<a href='{$ads[$i]['reklamlink']}'>Link</a>";
            echo "</div>";
        }
    } else {
        echo "<p>Senki nem szponzorál minket :(</p>";
    }
    $conn->close();
    ?>