<?php /* sample snippet stackoverflow-ról, nem biztos, hogy megy,
ÁTDOLGOZNI SZINTE MINDENT!!!
require_once 'SQL/connection.php'; // Adatbázis kapcsolat

// 1-es vonal megállóinak lekérése
$sql = "SELECT megallok.megallo_id, megallok.megallo_nev 
        FROM megallok 
        JOIN vonalak ON megallok.megallo_id = vonalak.megallo_id 
        WHERE vonalak.vonal_id = 1";
$result = $conn->query($sql);

echo "<h1>1-es vonal megállói</h1>";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<p>{$row['megallo_id']}: {$row['megallo_nev']}</p>";
    }
} else {
    echo "<p>Nincs megálló az 1-es vonalon.</p>";
}
?>
*/