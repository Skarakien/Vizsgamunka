/* Elérhetőségeink:
Telefon: +36/70-123-456-78
E-mail: mecsekhunyad@regio.volan.hu
7302 Mecsekhunyad, Szent Barabás utca 10/B */