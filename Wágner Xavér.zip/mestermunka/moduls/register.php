<?php
$felhasznalo = filter_input(INPUT_POST, 'felhasznalo', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$jelszo = filter_input(INPUT_POST, 'jelszo', FILTER_SANITIZE_STRING);
if ($email && $felhasznalo && $jelszo) {
    $stmt = $conn->prepare("INSERT INTO regisztralt (felhasznalo, email, jelszo) VALUES (?, ?, ?)");
    $stmt->bind_param("ss", $felhasznalo, $email, $jelszo);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    echo "Sikeres regisztráció!";
} else {
    echo "Hibás adatok! Kérlek próbáld újra.";
}
?>
