<?php
session_start();
require_once 'SQL/connection.php';
$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;
$userRank = $_SESSION['rank'] ?? null;
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Mecsekhunyadi Volán társaság</title>
        <link rel="stylesheet" type="text/css" href="css/main.css">
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
        <script type="text/javascript" src="js/scriptbackground.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>
    <body>
        <div class="banner">
            <div class="logo">
                <img src="images/logo.png" alt="Mecsekhunyad Volán" width="150" height="150">
            </div>
            <!-- szépítgetni kell -->
            <?php 
                if (!$isLoggedIn):
            ?>
            <button class="button" onclick="document.getElementById('loginbox').style.display='block'" style="width:auto;">Belépés</button>
            <div id="loginbox" class="elougro">
                <span onclick="document.getElementById('loginbox').style.display='none'" class="close">&times;</span>
                <form class="elougro-content animate" action="moduls/login.php" method="post">                        <div class="container">
                    <label for="email"><b>Email</b></label>
                    <input id="email" type="text" placeholder="kötelező kitölteni" name="email" required>
                    <label for="jelszo"><b>Jelszó</b></label>
                    <input id="jelszo" type="password" placeholder="bármit elfogad" name="jelszo" required>
                    <button type="submit">Belépés</button>
                    <div class="container" style="background-color:#f1f1f1">
                        <button type="button" onclick="document.getElementById('loginbox').style.display='none'" class="cancelbtn">Mégse</button>
                    </div>
                </form>
                <?php
                if( $_POST["email"]== "document.getElementById(loginbox.email).value" && $_POST["jelszo"]=="getElementById(loginbox.jelszo).value" ){
	                echo("Beléphetsz!");
	            }
	            else {
		            echo("Hibás belépési adatok!");
	            }
                ?>
            </div>
            <!-- Ezt még nem működik rendesen, hiába, ollóztam :) -->
            <button class="button" onclick="location.href='moduls/register.php'">Regisztráció</button>
            <div id="loginbox" class="elougro">
                <form class="elougro-content animate" action="moduls/register.php" method="post">
                    <div class="container">
                        <span onclick="document.getElementById('loginbox').style.display='none'" class="close">&times;</span>
                        <form action="moduls/register.php" method="post">
                            <div class="container">
                                <label for="felhasznalo"><b>Felhasználó-neved:</b></label>
                                <input type="text" placeholder="Ezt látják majd a többiek" name="felhasznalo" id="felhasznalo" required>
                                <label for="email"><b>E-mail-címed:</b></label>
                                <input type="text" placeholder="példa@doméjn.hu" name="email" id="email" required>
                                <label for="jelszo"><b>Jelszó</b></label>
                                <input type="text" placeholder="Bármit elfogad" name="jelszo" id="jelszo" required>
                                <label for="psw-repeat"><b>Jelszó megerősítés</b></label>
                                <input type="text" placeholder="Ugyanannak kell lennie!" name="psw-repeat" id="psw-repeat" required>
                                <hr>
                                <button type="submit" class="registerbtn">Regisztráció</button>
                            </div>
                            <div class="container signin">
                                <p>Már van fiókod?<a href="#">Lépj be itt!</a></p>
                            </div></form>
                    </div>
                </form>
            </div>
            <?php else: ?>
                <button class="button" onclick="location.href='moduls/logout.php'">Kilépés</button>
            <?php endif; ?>
            <button class="button" onclick="location.href='moduls/menetrendek.php'">Menetrendek</button>
        </div>
        <div class="oldalsav">
            <a href="moduls/jegyek.php" class="gomb">Jegyek</a>
            <a href="moduls/terkep.php" class="gomb">Térkép</a>
            <a href="moduls/rolunk.php" class="gomb">Rólunk</a>
            <?php if ($isLoggedIn): ?>
                <a href="uzenofal.php" class="gomb">Üzenőfal</a>
            <?php endif; ?>
        </div>
        <div class="tartalom">
            <div class="hirek_box">
                <?php
                include "moduls/hirek.php";
                ?>
            </div>
            <div class="háttér">
                <canvas id='canvas'></canvas>
            </div>
            <?php
            if (isset($_GET['module'])) {
                $module = $_GET['module'];
                include "moduls/{$module}.php";
            }
            elseif ($isLoggedIn) {
                if ($userRank == 4) {
                    include "moduls/vasarlo.php";
                } elseif ($userRank == 2) {
                    include "moduls/sofor.php";
                } elseif ($userRank == 3) {
                    include "moduls/szerelo.php";
                } elseif ($userRank == 1) {
                    include "moduls/admin.php";
                }
            }else {
                echo "<div class='szöveg'>Üdvözöljük a Mecsekhunyadi Volán társaság oldalán!</div>";
            }
            ?>
        </div>
        <div class="reklamok_box">
            <?php
            include "moduls/reklam.php";
            ?>
        </div>
    </body>
</html>