# **Volán online weboldal**  
**Menetrendek, buszok helyzetének lekérése és jegyek vásárlása**   
Work In Progress Minimum Valueable Product edisön  

## Telepítés és konfigurálás

A project tartalmaz HTML, CSS, JS, PHP elemeket.

## Az oldal célja

Az oldalt azért hoztam létre, hogy (jelenleg) 4 különböző igényt egyesítsünk egy helyen, így ugyan biztonsági kockázatokat vállalunk, de egyszerűbb és gyorsabb kiszolgálást biztosítunk. A vásárlók (és a kiszolgálószemélyzet tagjai) látnák a járművek elérhetőségét, jegyet válthatnak az utazás előtt/közben, értesülhetnek a késésekről. A személyzetnek továbbá könnyebb dolga lenne jelezni a késéseket mind az utasok számára, mind a szolgáltatás fenntartói irányába.  

**Mindezt valós időben!**

Ugyan mindez szerény webes szolgáltatás, de így is több, mint amennyit a mai volán appok biztosítanak. Mindemellett bővíthető későbbi igényeknek megfelelő snipetekkel.  

A 4 felhasználói osztályok, melyekre az oldalt szabtam:  

1. Utasok  
2. Sofőrök  
3. Adminisztrátorok (ebbe a jegypénztárosok és a managemant tagjai is bele tartoznak)  
4. Szerelők  

(Mint írtam, ezek száma bővíthető vagy átrendezhető)

És az igények, melyeket teljesíteni akartam (ömlesztve, footnote-ban a felhasználó osztálya):  
- account létrehozása [^1] [^3] [x] [x]  
- account módosítása [^3] [x]  
- account törlése [^1] [^3] [] [x]  
- jegy vásárlása [^1] [^2] [] []  
- jegy átruházása [^1] [] 
- jegy árának módosítása, hozzáadása [^3] [x]  
- készpénz feltöltése kreditre [^1] [^2] [^3] [] [] []   
- kredit egyenleg lekérdezése [^1] [^3] [] []  
- megálló létrehozása [^3] [x]  
- megálló menetrendjének lekérése [^1] [^2] [^3] [] [] []  
- kedvenc/gyakran használt megálló létrehozása, törlése [^1] [] 
- megálló törlése [^3] [x]  
- vonal létrehozása [^3] []  
- vonal törlése [^3] []  
- vonal favorizálása [^1] []  
- vonal menetrendjének lekérése [^1] [^2] [^3] [] [] []  
- ideiglenes megállóhely kijelölése [^3] [x]  
- vonalon észlelt akadály jelentése [^2] [^3] [] []  
- vonalon lévő akadály lekérése [^2] [^3] [] [] 
- napi menetlevél létrehozása [^3] [] []  
- napi menetlevél lekérése [^2] [^3] [] []  
- navigációs térkép szerkesztése [^3] []  
- navigációs térkép lekérése [^1] [^2] [^3] [] [] []  
- menetidő meghatározása [^3] []  
- menetidő lekérdezése [^1] [^2] [^3] [] [] []  
- menetidő ideiglenes módosítása (késés miatt) [^2] [^3] [] []  
- menetidő állandó módosítása (menetrend átalakítás) [^3] []  
- várható várakozás megjelenítése a kijelölt megállóban [^1] [^3] [] []  
- következő megálló adatainak megjelenítése [^1] [^2] [] []  
- busz hibájának jelentése [^2] [^3] [^4] []  
- busz hibájának törlése [^4] []  
- busz szerelőhöz küldése [^3] [^4] [] []  
- busz "pihentetése" [^3] [^4] [] []  
- "pihenő" buszok listájának megjelenítése [^2] [^3] [^4] [] [] []   
- buszok sofőrhöz rendelése [^2] [^3] [] []  
- elérhető sofőrök listájának lekérése [^2] [^3] [] []  
- elérhető szerelők listájának lekérése [^3] [^4] [] []  
- online chatszoba és üzenőfal/fórum (lehetőleg Ejabberd vagy Java nyelven írt) [^1] [^2] [^3] [^4]

[^1]: vásárló  
[^2]: sofőr  
[^3]: admin  
[^4]: szerelő  

## A front-end felépítése  

### Általános kezdőképernyő  

Ez jelenik meg, ha még nem regisztráltunk, innen kiindulva kapjuk meg a jegy/bérlet árait, megállókat, menetrendet, regisztrálhatunk, elérhetőségek, illetve nézhetjük meg, hogy mennyi busz jár jelenleg a városban. Innen érhető el a bejelentkezés után a többi kezelőfelület.
Egy vonalat betöltve megkapjuk a menetrendet, megállókat, az éppen járó buszok listáját, menetidőt.
Választhatunk megállókat, amikre kattintva betöltődik a menetrend, a vonalszámok, amik érintik.
Regisztrálhatunk és bejelentkezhetünk.

### Felhasználói képernyő  

Regisztrált felhasználóként itt érhetjük el a "kosarunkat", "ajándékozhatunk" jegyet más felhasználónak, vehetünk krediteket, "kedvencelhetünk", törölhetjük a fiókot, illetve minden alapfunkciót elérünk.


### Sofőr képernyő  

Itt jelenthetjük be a problémát a járművel, érhetjük el az aznapi vonalak tervét, amelyen haladnunk kell, jelenthetünk be problémát az útvonallal kapcsolatban és vásárolhatunk az utasok számára jegyet vagy bérletet.  

### Admin képernyő  

Jegyet válthatunk, sofőröknek kiadhatjuk a menetlevelet, szervízbe/garázsba küldhetünk buszokat, regisztrálhatunk új dolgozókat.  

### Szerelő képernyő  

Itt rögzíthetjük a buszokon végzett különböző tevékenységeket és figyelmeztethetünk a várható problémákra.  

## A back-end felépítése  

### Táblák  

Próbáltam külön szedni minden olyan táblázatot, amelyet egyesével ésszerűbb módosítani.  

### Modulok  

A lehető legtöbb funkciót, legyen akármilyen kicsi, külön modulba raktam, a könnyed implementálás érdekében.  

### Biztonság  

Erősen hiányos. Az első dolog, amit fejleszteni illene benne. (példa: "Bobby Tables" kiiktatása) 

# Mint látható a leadott projectmunkából, nagy falat ez a számomra.
##### Ha jót nem is sikerült csinálnom, legalább vicces lett, ami megvan belőle.
###### Legalábbis remélem.