-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2025. Ápr 15. 17:37
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `mestermunka`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `1-es vonal`
--

CREATE TABLE `1-es vonal` (
  `sorrendi_ID` int(4) NOT NULL COMMENT 'ebben a sorrendben közlekedik a busz!',
  `megallo_ID` int(4) NOT NULL COMMENT 'megállók azonosítója a megallok táblából'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `1-es vonal`
--

INSERT INTO `1-es vonal` (`sorrendi_ID`, `megallo_ID`) VALUES
(1, 29),
(2, 12),
(3, 4),
(4, 40),
(5, 32),
(6, 20),
(7, 19),
(8, 35),
(9, 25),
(10, 8),
(11, 15),
(12, 7);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `2-es vonal`
--

CREATE TABLE `2-es vonal` (
  `sorrendi_ID` int(4) NOT NULL COMMENT 'ebben a sorrendben közlekedik a busz!',
  `megallo_ID` int(4) NOT NULL COMMENT 'megállók azonosítója a megallok táblából'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `2-es vonal`
--

INSERT INTO `2-es vonal` (`sorrendi_ID`, `megallo_ID`) VALUES
(1, 1),
(2, 3),
(3, 18),
(4, 10),
(5, 34),
(6, 35),
(7, 40),
(8, 27),
(9, 18),
(10, 30),
(11, 11),
(12, 36),
(13, 25),
(14, 11),
(15, 5),
(16, 16),
(17, 18),
(18, 4),
(19, 23),
(20, 28);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `buszok`
--

CREATE TABLE `buszok` (
  `busz_ID` int(4) NOT NULL,
  `buszazonos` int(5) NOT NULL COMMENT 'buszazonosító',
  `rendszam` varchar(8) NOT NULL COMMENT 'rendszám',
  `szerviz` tinyint(1) NOT NULL COMMENT 'szervízbe küldve',
  `pihen` tinyint(1) NOT NULL COMMENT 'garázsban'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci COMMENT='Buszok listája';

--
-- A tábla adatainak kiíratása `buszok`
--

INSERT INTO `buszok` (`busz_ID`, `buszazonos`, `rendszam`, `szerviz`, `pihen`) VALUES
(1, 1, 'MGT-103', 1, 0),
(2, 2, 'MGT-105', 0, 1),
(3, 4, 'MGT-109', 0, 0),
(4, 7, 'NED-452', 0, 0),
(5, 8, 'NFA-367', 0, 1),
(6, 9, 'NFA-560', 0, 0),
(7, 11, 'NFA-561', 1, 0),
(8, 12, 'NFA-562', 0, 0),
(9, 13, 'NFA-593', 0, 0),
(10, 14, 'NFA-596', 0, 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `hirek`
--

CREATE TABLE `hirek` (
  `hir_ID` int(11) NOT NULL,
  `hirkep` varchar(250) NOT NULL COMMENT 'esetleges kép linkje',
  `hircim` varchar(60) NOT NULL COMMENT 'hirdetmény címe',
  `hirido` date NOT NULL COMMENT 'közzététel ideje',
  `hirszoveg` varchar(1000) NOT NULL COMMENT 'hirdetmény szövege'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `hirek`
--

INSERT INTO `hirek` (`hir_ID`, `hirkep`, `hircim`, `hirido`, `hirszoveg`) VALUES
(1, '', 'Elindultunk!', '2002-01-01', 'Végre, oly sok év várakozás után, mélyen tisztelt Városunkban is elindult a mobilizációs forradalom! Idősb Gépzsíros Nyumurdzsák Polgármester elvágta azt az akadályt jelző szalagot, mely eddig visszatartotta ezt a csodaszép, zöld, hazafias és sikerekre teremtetett közösséget a saját, önerőből fenntartott buszközlekedés elől.'),
(3, '', 'SZTRÁJK', '2025-04-19', 'Most vasárnap, a szokásos éves paraszt-sztrájkok alkalmából rendezett szolidaritási munkabeszüntetés miatt minden sofőrünk otthon marad, emiatt egy járat fog csak közlekedni, melyet a tapasztalatokban nem jártas Igazgató úr fog vezetni.');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `jaratok`
--

CREATE TABLE `jaratok` (
  `vonal_ID` int(11) NOT NULL,
  `vonalszam` int(3) NOT NULL COMMENT 'járatszám',
  `buszazonos` int(4) NOT NULL COMMENT 'buszazonosító',
  `menetido` int(3) NOT NULL COMMENT 'menetidő',
  `indulas` time NOT NULL COMMENT 'indulási idő',
  `megallo_ID` int(6) NOT NULL COMMENT 'megálló egyedi száma',
  `soforID` int(4) NOT NULL COMMENT 'sofőr azonosító'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci COMMENT='Járatok listája';

--
-- A tábla adatainak kiíratása `jaratok`
--

INSERT INTO `jaratok` (`vonal_ID`, `vonalszam`, `buszazonos`, `menetido`, `indulas`, `megallo_ID`, `soforID`) VALUES
(1, 1, 0, 15, '00:00:00', 0, 0),
(2, 2, 0, 20, '00:00:00', 0, 0),
(3, 3, 0, 40, '00:00:00', 0, 0),
(4, 4, 0, 45, '00:00:00', 0, 0),
(5, 5, 0, 60, '00:00:00', 0, 0),
(6, 6, 0, 35, '00:00:00', 0, 0),
(7, 7, 0, 90, '00:00:00', 0, 0),
(8, 8, 0, 110, '00:00:00', 0, 0),
(9, 9, 0, 40, '00:00:00', 0, 0),
(10, 16, 0, 35, '00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `javitasok`
--

CREATE TABLE `javitasok` (
  `buszazonos` int(4) NOT NULL COMMENT 'buszazonosító',
  `problema` varchar(300) NOT NULL COMMENT 'probléma leírása',
  `javitas` varchar(300) NOT NULL COMMENT 'kijavított rész',
  `megszerelve` date NOT NULL COMMENT 'utolsó szervíz dátuma',
  `figyelem` varchar(300) NOT NULL COMMENT 'következő vélt meghibásodó alkatrész',
  `vizsgalo` varchar(20) NOT NULL COMMENT 'ki javította',
  `jav_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci COMMENT='Javítások listája';

--
-- A tábla adatainak kiíratása `javitasok`
--

INSERT INTO `javitasok` (`buszazonos`, `problema`, `javitas`, `megszerelve`, `figyelem`, `vizsgalo`, `jav_ID`) VALUES
(1, 'Futómű', 'Kuplung, gyertyacsere, olajcsere', '0000-00-00', 'Téligumi!!!!!!', '', 1),
(2, '', 'Ablakmosó folyadék', '2025-04-01', 'TÉLIGUMI!!!!!', 'Géza', 2),
(4, '', 'Légterelők felszerelve! :)', '2024-08-22', 'Lötyögő kipufogó.', 'Géza', 3),
(7, '', 'Hornfalvai Volántól átvéve.', '2024-07-10', 'Ülések ramaty állapotban. És büdösek is.', 'Géza', 4),
(8, '', 'Fényszórócsere.', '2025-01-16', 'Alvázmosás kell majd ősszel.', 'Géza', 5),
(9, '', 'Karburátor cserélve.', '2025-02-12', '100 000 kilométer!', 'Géza', 6),
(11, 'Téligumi csere', 'Ablakmosó folyadék csere, téligumi csere.', '0000-00-00', 'Lejáró műszaki!', 'Géza', 7),
(12, '', 'Lengéscsillapító cserélve.', '2025-03-01', 'FESTÉS!!!!!', 'Géza', 8),
(13, '', 'Szélvédő pótlása', '2025-04-02', 'Nincs szigetelve rendesen az ablak!', 'Géza', 9),
(14, '', 'Átvéve a Guruguru Nippon autógyárból', '2025-04-15', '', 'Géza', 10);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `jegyek`
--

CREATE TABLE `jegyek` (
  `jegytipus` varchar(40) NOT NULL COMMENT 'jegyek típusa',
  `jegyar` int(6) NOT NULL COMMENT 'áruk',
  `vetelido` datetime NOT NULL COMMENT 'érvényesség kezdete',
  `jegy_index` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci COMMENT='jegyek listája';

--
-- A tábla adatainak kiíratása `jegyek`
--

INSERT INTO `jegyek` (`jegytipus`, `jegyar`, `vetelido`, `jegy_index`) VALUES
('vonaljegy', 300, '0000-00-00 00:00:00', 1),
('napi jegy', 500, '0000-00-00 00:00:00', 2),
('heti bérlet', 2500, '0000-00-00 00:00:00', 3),
('havi bérlet', 7500, '0000-00-00 00:00:00', 4),
('éjszakai jegy', 300, '0000-00-00 00:00:00', 5),
('éves bérlet', 75000, '0000-00-00 00:00:00', 6);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `megallok`
--

CREATE TABLE `megallok` (
  `megallo_ID` int(6) NOT NULL COMMENT 'megálló egyedi száma',
  `megallo_nev` varchar(200) NOT NULL COMMENT 'megálló neve',
  `koordinata` point NOT NULL COMMENT 'megálló koordinátái'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci COMMENT='Megállók tömbje';

--
-- A tábla adatainak kiíratása `megallok`
--

INSERT INTO `megallok` (`megallo_ID`, `megallo_nev`, `koordinata`) VALUES
(1, 'Petőfi utca', 0x000000000101000000000000000000f03f0000000000002440),
(2, 'Nagy Domonkos köz', 0x00000000010100000000000000000043400000000000804b40),
(3, 'Répa tér', 0x00000000010100000000000000008041400000000000c05840),
(4, 'Szent Auguszta sugárút', 0x00000000010100000000000000000056400000000000004a40),
(5, 'Golgota Stadion', 0x0000000001010000000000000000804b400000000000003b40),
(6, '3-as tröszt épület', 0x00000000010100000000000000008057400000000000003d40),
(7, 'Dominikátus söröző', 0x00000000010100000000000000000052400000000000000040),
(8, 'Bajtárs elágazó', 0x00000000010100000000000000008043400000000000804440),
(9, 'Ignác Templom', 0x00000000010100000000000000000040400000000000003d40),
(10, 'Jóreménység út', 0x00000000010100000000000000000024400000000000005740),
(11, 'Autóbusz végállomás', 0x00000000010100000000000000000037400000000000004440),
(12, 'Kadarka-hegy', 0x00000000010100000000000000000000000000000000003b40),
(13, 'ÁGP', 0x00000000010100000000000000000036400000000000405340),
(14, 'Galagonya dűlő', 0x0000000001010000000000000000002c400000000000004240),
(15, 'Marx utca', 0x00000000010100000000000000000055400000000000005140),
(16, 'Kinizsi tér', 0x00000000010100000000000000000045400000000000804540),
(17, '3-as villamos állomás', 0x00000000010100000000000000000042400000000000804a40),
(18, 'Tesco mélygarázs', 0x00000000010100000000000000004056400000000000004540),
(19, 'Langalló sugárút', 0x0000000001010000000000000000004e400000000000003c40),
(20, 'Vizes Nokedli', 0x0000000001010000000000000000c053400000000000003640),
(21, 'Csárdáskirálynő tér', 0x00000000010100000000000000000030400000000000405840),
(22, 'Zsupsz köz', 0x00000000010100000000000000000053400000000000002e40),
(23, 'Triglicerin sétáló', 0x00000000010100000000000000008042400000000000005840),
(24, 'Kék Park', 0x00000000010100000000000000000046400000000000004a40),
(25, 'Kátyú köz', 0x00000000010100000000000000000034400000000000003340),
(26, 'Miskakancsó', 0x00000000010100000000000000000035400000000000405040),
(27, 'Bábolnai út', 0x0000000001010000000000000000804b400000000000003340),
(28, 'Népakaratja út', 0x00000000010100000000000000004051400000000000004140),
(29, 'Mindhárom úti aluljáró', 0x00000000010100000000000000000028400000000000004940),
(30, 'Tél utca', 0x0000000001010000000000000000002c400000000000004140),
(31, 'Sziklapöröly út', 0x00000000010100000000000000004054400000000000804b40),
(32, 'Legolas tér', 0x00000000010100000000000000000049400000000000003540),
(33, 'Fedák Sári út', 0x0000000001010000000000000000001c400000000000005340),
(34, 'Malom malom', 0x00000000010100000000000000000034400000000000405740),
(35, 'Koppány köz', 0x0000000001010000000000000000004a400000000000004240),
(36, 'Cthulu utca', 0x00000000010100000000000000000053400000000000003a40),
(37, 'Göröngyösi ipartelep', 0x00000000010100000000000000000014400000000000805040),
(38, 'Gázgyár', 0x00000000010100000000000000000022400000000000405740),
(39, 'Villanyos kertek', 0x00000000010100000000000000000040400000000000004840),
(40, 'Töltés árok', 0x00000000010100000000000000004052400000000000c05340);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `menetrend`
--

CREATE TABLE `menetrend` (
  `menet_ID` int(11) NOT NULL,
  `vonalszam` int(3) NOT NULL COMMENT 'járatszám',
  `indulas` time NOT NULL COMMENT 'indulási idő',
  `napok` varchar(4) NOT NULL COMMENT 'hét melyik napja'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `menetrend`
--

INSERT INTO `menetrend` (`menet_ID`, `vonalszam`, `indulas`, `napok`) VALUES
(1, 1, '05:30:00', 'munk'),
(2, 1, '05:45:00', 'munk'),
(3, 1, '06:20:00', 'munk'),
(4, 1, '06:30:00', 'szun'),
(5, 1, '07:20:00', 'szab'),
(6, 1, '07:20:00', 'munk'),
(7, 1, '08:10:00', 'munk'),
(8, 2, '05:20:00', 'munk'),
(13, 1, '08:45:00', 'munk'),
(14, 1, '10:40:00', 'munk'),
(15, 1, '11:40:00', 'munk'),
(16, 1, '13:10:00', 'munk'),
(17, 1, '14:50:00', 'munk'),
(18, 1, '15:45:00', 'munk'),
(19, 1, '16:10:00', 'munk'),
(20, 1, '16:30:00', 'munk'),
(21, 1, '16:50:00', 'munk'),
(22, 1, '17:20:00', 'munk'),
(23, 1, '17:50:00', 'munk'),
(24, 1, '18:30:00', 'munk'),
(25, 1, '19:20:00', 'munk'),
(26, 1, '19:50:00', 'munk'),
(27, 1, '20:30:00', 'munk'),
(28, 1, '21:00:00', 'munk'),
(29, 1, '22:00:00', 'munk'),
(30, 1, '23:00:00', 'munk'),
(31, 2, '06:30:00', 'munk'),
(32, 2, '08:00:00', 'munk'),
(33, 2, '10:00:00', 'munk'),
(34, 2, '13:35:00', 'munk'),
(35, 2, '16:20:00', 'munk'),
(36, 2, '19:25:00', 'munk'),
(37, 2, '10:45:00', 'szab'),
(38, 3, '10:35:00', 'munk'),
(39, 3, '14:25:00', 'munk'),
(40, 3, '12:10:00', 'szun');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `regisztralt`
--

CREATE TABLE `regisztralt` (
  `ID` int(11) NOT NULL,
  `email` varchar(64) NOT NULL COMMENT 'e-mailcím',
  `felhasznalonev` varchar(32) NOT NULL COMMENT 'felhasználónév',
  `jelszo` varchar(32) NOT NULL COMMENT 'jelszó',
  `felhasz_osztaly` int(1) NOT NULL COMMENT 'rang'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci COMMENT='Felhasználók listája';

--
-- A tábla adatainak kiíratása `regisztralt`
--

INSERT INTO `regisztralt` (`ID`, `email`, `felhasznalonev`, `jelszo`, `felhasz_osztaly`) VALUES
(1, 'sandor.teleki@mecsekhunyad.volan.hu', 'sanyi01', 'Szeretemasajtot', 1),
(2, 'huszarandrasalezredes@mecsekhunyad.volan.hu', 'igazgatour', 'jelszo', 1),
(3, 'vargasandor@mecsekhunyad.volan.hu', 'sanyi02', 'UtálomAzÖsszesSajtot1', 2),
(4, 'geza_a_faszagyerek@mecsekhunyad.volan.hu', 'szakigéza', 'sufnituning!', 3),
(5, 'nemeseliza@mecsekhunyad.volan.hu', 'lizacica', 'Szoboszlaifullcuki', 1),
(6, 'nagynemarika@freemail.com', 'nagynémarika', 'nagynémarika', 4),
(7, 'sajtostoni@gmail.hu', 'Tónibá_a_pék', 'turostaska01', 0),
(8, 'gamerpisti@tryhackme.com', 'xXxD3s7r0y3rxXx', '360noscope', 4),
(9, 'kemenylujza@mecsekhunyad.volan.hu', 'Lujzika', 'cucika1', 2),
(10, 'gattaca@emailfor.free', 'NagyÁrpád', 'Oppenheimer', 4),
(11, 'gerhart@jarompuszta.volan.hu', 'gerhart1', 'imbuszkulcs', 3),
(12, 'terinenje1938@citromail.hu', 'terineni1', 'eljenSzalasi', 4),
(13, 'morbidguyfromthesky@mail.warez.torrent.com', 'GálJózsi', 'igenisleteznek420', 4);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `reklamok`
--

CREATE TABLE `reklamok` (
  `reklam_ID` int(11) NOT NULL,
  `reklamnev` varchar(40) NOT NULL COMMENT 'reklám "neve"',
  `reklamkep` varchar(255) NOT NULL COMMENT 'kép linkje',
  `reklamlink` varchar(255) NOT NULL COMMENT 'redirect'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `reklamok`
--

INSERT INTO `reklamok` (`reklam_ID`, `reklamnev`, `reklamkep`, `reklamlink`) VALUES
(1, 'Boss mosogatógép', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQH7fp3EhAF2cyc_-gw0snjmo-FEWJaGwR-rQ&s', 'www.emag.hu'),
(4, 'Pick disznósajt akció (Tesco, 2025, ápri', 'https://st2.depositphotos.com/2021005/10401/i/450/depositphotos_104012474-stock-photo-abstract-psychedelic-wallpape.jpg', 'www.vatera.hu'),
(5, 'Gyomirtó', 'https://i0.wp.com/meow.af/wp-content/uploads/2024/08/Snapinsta.app_433550476_794812185890465_8428804107180914316_n_1080.jpg', 'www.rosszlanyok.hu'),
(6, 'Dunaszenttaksony tours', 'https://i.ytimg.com/vi/A43Wr6fBFNg/maxresdefault.jpg', 'www.google.com');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `1-es vonal`
--
ALTER TABLE `1-es vonal`
  ADD PRIMARY KEY (`sorrendi_ID`);

--
-- A tábla indexei `2-es vonal`
--
ALTER TABLE `2-es vonal`
  ADD PRIMARY KEY (`sorrendi_ID`);

--
-- A tábla indexei `buszok`
--
ALTER TABLE `buszok`
  ADD PRIMARY KEY (`busz_ID`);

--
-- A tábla indexei `hirek`
--
ALTER TABLE `hirek`
  ADD PRIMARY KEY (`hir_ID`);

--
-- A tábla indexei `jaratok`
--
ALTER TABLE `jaratok`
  ADD PRIMARY KEY (`vonal_ID`);

--
-- A tábla indexei `javitasok`
--
ALTER TABLE `javitasok`
  ADD PRIMARY KEY (`jav_ID`);

--
-- A tábla indexei `jegyek`
--
ALTER TABLE `jegyek`
  ADD PRIMARY KEY (`jegy_index`);

--
-- A tábla indexei `megallok`
--
ALTER TABLE `megallok`
  ADD PRIMARY KEY (`megallo_ID`);

--
-- A tábla indexei `menetrend`
--
ALTER TABLE `menetrend`
  ADD PRIMARY KEY (`menet_ID`);

--
-- A tábla indexei `regisztralt`
--
ALTER TABLE `regisztralt`
  ADD PRIMARY KEY (`ID`);

--
-- A tábla indexei `reklamok`
--
ALTER TABLE `reklamok`
  ADD PRIMARY KEY (`reklam_ID`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `1-es vonal`
--
ALTER TABLE `1-es vonal`
  MODIFY `sorrendi_ID` int(4) NOT NULL AUTO_INCREMENT COMMENT 'ebben a sorrendben közlekedik a busz!', AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT a táblához `2-es vonal`
--
ALTER TABLE `2-es vonal`
  MODIFY `sorrendi_ID` int(4) NOT NULL AUTO_INCREMENT COMMENT 'ebben a sorrendben közlekedik a busz!', AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT a táblához `buszok`
--
ALTER TABLE `buszok`
  MODIFY `busz_ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT a táblához `hirek`
--
ALTER TABLE `hirek`
  MODIFY `hir_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT a táblához `jaratok`
--
ALTER TABLE `jaratok`
  MODIFY `vonal_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT a táblához `javitasok`
--
ALTER TABLE `javitasok`
  MODIFY `jav_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT a táblához `jegyek`
--
ALTER TABLE `jegyek`
  MODIFY `jegy_index` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT a táblához `megallok`
--
ALTER TABLE `megallok`
  MODIFY `megallo_ID` int(6) NOT NULL AUTO_INCREMENT COMMENT 'megálló egyedi száma', AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT a táblához `menetrend`
--
ALTER TABLE `menetrend`
  MODIFY `menet_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT a táblához `regisztralt`
--
ALTER TABLE `regisztralt`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT a táblához `reklamok`
--
ALTER TABLE `reklamok`
  MODIFY `reklam_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
